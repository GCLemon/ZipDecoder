using System;
using System.Diagnostics;

class leibnitz
{
    public static void Main()
    {
        Stopwatch stopwatch = new Stopwatch();

        double piQuater = 0;
        double piQuaterTrue = Math.PI / 4;

        stopwatch.Start();

        long start = stopwatch.ElapsedTicks;
        for(double i = 0; Math.Abs(piQuater - piQuaterTrue) > 0.00000001; ++i)
            piQuater += Math.Pow(-1, i) / (2 * i + 1);
        long finish = stopwatch.ElapsedTicks;
        long time = finish - start;

        stopwatch.Stop();

        Console.WriteLine("Answer : π = " + piQuater * 4);
        Console.WriteLine("Time : " + time / 1_000_000_000 + "." + time % 1_000_000_000 + " [sec.]");
    }
}