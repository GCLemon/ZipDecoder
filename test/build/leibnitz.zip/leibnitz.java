import static java.lang.System.*;

public class leibnitz
{
    public static void main(String[] args)
    {
        double piQuater = 0;
        double piQuaterTrue = Math.PI / 4;

        long start = nanoTime();
        for(double i = 0; Math.abs(piQuater - piQuaterTrue) > 1.0e-8; ++i)
            piQuater += Math.pow(-1, i) / (2 * i + 1);
        long finish = nanoTime();
        long time = finish - start;

        out.println("Answer : π = " + piQuater * 4);
        out.println("Time : " + time / 1_000_000_000 + "." + time % 1_000_000_000 + " [sec.]");
    }
}