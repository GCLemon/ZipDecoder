piQuater = 0
piQuaterTure = math.pi / 4

start = os.clock()
i = 0
while math.abs(piQuater - piQuaterTure) > 1.0e-8 do
    piQuater = piQuater + math.pow(-1, i) / (2 * i + 1)
    i = i + 1
end
finish = os.clock()
elapsed = finish - start

print("Answer : π = ", piQuater * 4)
print("Time = ", elapsed, " [sec.]")