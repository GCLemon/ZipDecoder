import math, time

piQuater = 0
piQuaterTure = math.pi / 4

start = time.time()
i = 0
while math.fabs(piQuater - piQuaterTure) > 1.0e-8:
    piQuater += math.pow(-1, i) / (2 * i + 1)
    i += 1
finish = time.time()
elapsed = finish - start

print("Answer : π = " + str(piQuater * 4))
print("Time = " + str(elapsed) + " [sec.]")