#include <cmath>
#include <cstdio>
#include <ctime>

int main()
{
    struct timespec start, finish;

    double piQuater = 0;

    clock_gettime(CLOCK_REALTIME, &start);
    for(double i = 0; abs(piQuater - M_PI_4) > 1.0e-8; ++i)
        piQuater += pow(-1, i) / (2 * i + 1);
    clock_gettime(CLOCK_REALTIME, &finish);

    long time_nsec = finish.tv_nsec - start.tv_nsec;
    while(time_nsec < 0)
    {
        --finish.tv_sec;
        time_nsec += 1000000000;
    }
    long time_sec = finish.tv_sec - start.tv_sec;

    printf("Answer : π = %lf\n", piQuater * 4);
    printf("Time : %ld.%09ld [sec.]\n", time_sec, time_nsec);

    return 0;
}